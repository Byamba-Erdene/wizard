const serialNumber = require('serial-number');
const fetch = require('node-fetch');

const roomName = 'M301';
const skuNumber = process.argv[2];

if (!skuNumber) {
  console.error('skuNumber requied, try: `node index.js <skuNumber>`');
  process.exit(1);
}

const serviceLink = `https://int-device-management-service.vercel.app/api/a75e0601095a`;
// const serviceLink = `http://localhost:4200/api/a75e0601095a`;

serialNumber(async function (err, serialNumber) {
  const result = await fetch(serviceLink, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      roomName,
      skuNumber,
      serialNumber,
    }),
  })
    .then((response) => response.json())
    .catch((e) => console.error(e));

  console.log(result);
});
